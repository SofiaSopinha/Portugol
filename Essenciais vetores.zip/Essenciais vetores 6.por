programa
{
	
	funcao inicio()
	{
		//Crie um algoritmo que peça ao usuário que informe oito (8) números inteiros e os armazene-os em um vetor.
		//Apresente o maior elemento e a posição em que ele se encontra no vetor. 

		inteiro num[8] 
		inteiro valor
		escreva("Digite 8 números e eu direi qual é o maior deles.")
		para(inteiro i=0; i < 8; i++){

		escreva("\nDigite um número pra posição ", (i + 1), ": ")
			leia(valor)
			num[i] = valor
			}
		inteiro maior = num[0]
		inteiro posicao = 0
		para(inteiro i=0; i < 8; i++){
			se(num[i] > maior){
				maior = num[i]
   				posicao = i
			}
		}
		
			escreva("o maior número que você indicou é o número ", maior, " na posição ", (posicao + 1))
		
	}
		
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 697; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */