programa
{
	
	funcao inicio()
	{
		//Crie um vetor para armazenamento de nomes de frutas, armazene 5 frutas e exiba os valores armazenados no vetor com um laço de repetição.

			cadeia frutas[5] = {"Maçã" , "Pera" , "Uva" , "Abacaxi" , "Coco"}
		para(inteiro indice = 0; indice <= 4; indice++) {
    escreva(frutas[indice], "\n")}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 287; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */