programa
{
	
	funcao inicio()
	{
		//Crie um algoritmo que armazene números de 1 a 100  (ordem crescente) em um vetor e exiba-os.

		inteiro num[100]
		para(inteiro i=0; i < 100; i++){
		num[i] = i + 1
		}
		para(inteiro i=0; i < 100; i++){
		escreva(num[i], "\n")
		}


	}
}

/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 168; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */