programa
{
	
	funcao inicio()
	{
//Crie um vetor com 4 palavras (cadeia de caracteres) e então escreva um algoritmo que inverta a posição
//destas palavras no vetor (uma variável auxiliar será necessária)   



cadeia palavras [4] = {"Água","Terra","Fogo","Ar"}
para(inteiro i=0; i < 4; i++){
escreva(palavras[i], "\n")}
		
cadeia aux = palavras [0]
palavras[0] = palavras[3]
palavras [3] = aux

escreva("\n")
para(inteiro i=0; i < 4; i++){
escreva(palavras[i], "\n")}
		}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 259; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */