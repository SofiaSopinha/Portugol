programa
{
	
	funcao inicio()
	{
		//Dado um vetor de idades (inteiro idades[4] = {14, 15, 15, 16}), faça um programa que exibe a primeira e a última idade armazenada no vetor.
			inteiro idade[4] = {14, 15, 15, 16}
    escreva( idade[0], "\n")
    escreva( idade[3], "\n")
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 254; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */