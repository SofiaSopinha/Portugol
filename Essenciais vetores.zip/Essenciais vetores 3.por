programa
{
	
	funcao inicio()
	{
		//Crie um vetor de variáveis logico que armazena se o jogador concluiu ou não (verdadeiro, falso) as 5 fases de um jogo. Exiba com um laço de repetição quais fases o jogador concluiu ou não.

			logico jogos[5] = {verdadeiro, falso, falso, verdadeiro, verdadeiro}
		para(inteiro indice = 0; indice < 5; indice++) {
			se (jogos[indice] == verdadeiro){
				escreva("Fase #" + (indice + 1) + " concluída\n")
			}
			senao{
				escreva("Fase #" + (indice + 1) + " não concluída\n")
			}
		}
			
		
    
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 501; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */