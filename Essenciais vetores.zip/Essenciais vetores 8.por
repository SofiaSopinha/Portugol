programa
{
	
	funcao inicio()
	{

		//Crie um vetor com as siglas dos estados da região sudeste do Brasil. 
		//Faça um programa que solicite ao usuário a sigla de um estado e responda se esta sigla
		//é ou não de um estado do sudeste.

		  cadeia estados[4] = {"ES", "MG", "RJ", "SP"}
		  cadeia sigla
		  escreva("Insira a sigla de um estado e eu direi se ele faz parte da região sudeste.\n")
		  escreva("Insira a sigla (em caixa alta): ")
		  leia(sigla)

			logico encontrado = falso 
			
		  para(inteiro posicao = 0; posicao < 4; posicao++){
			se (sigla==estados[posicao]){
			escreva("O estado de ", estados[posicao], " faz parte do sudeste.")
			encontrado = verdadeiro
           	pare
            }	}
            se (nao encontrado){
        escreva("O estado de ", sigla, " não faz parte do sudeste.")}

	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 817; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */