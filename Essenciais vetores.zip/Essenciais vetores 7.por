programa
{
	
	funcao inicio()
	{
	
	//Crie um vetor com 6 números inteiros, utilizando um laço de repetição faça a soma dos valores 
	//armazenados neste vetor. Exiba o resultado ao final do programa.

escreva("Os números são: \n")
inteiro num [6] = {2,5,6,3,2,9}
inteiro soma = 0
para(inteiro i=0; i <6; i++){
	escreva(num[i], "\n")
  soma = soma + num[i]}

escreva("A soma dos números é "+ soma ,"\n")
	
}}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 389; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */