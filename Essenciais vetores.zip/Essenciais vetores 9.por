programa
{
    funcao inicio()
    {
       
        cadeia produtos[8]
        real precos[8]

        para(inteiro i = 0; i < 8; i++)
        {
            escreva("Digite o nome do produto ", i + 1, ": ")
            leia(produtos[i])

            escreva("Digite o preço do produto ", i + 1, ": ")
            leia(precos[i])

            escreva("\n")
        }

        escreva("\n========================================\n")
        escreva("      TABELA DE PRODUTOS CADASTRADOS\n")
        escreva("========================================\n")
        escreva("| PRODUTO                | PREÇO     |\n")
        escreva("========================================\n")
        para(inteiro i = 0; i < 8; i++)
        {
            escreva("| ", produtos[i], " \t\t\t | R$ ", precos[i], " |\n")
        }

        escreva("========================================\n")
    }
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 594; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */