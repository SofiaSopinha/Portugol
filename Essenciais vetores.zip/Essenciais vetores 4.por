programa
{
	
	funcao inicio()
	{
		//Crie um vetor com 10 números inteiros, utilizando um laço de repetição faça:
		//A exibição do vetor na ordem em que os elementos foram inseridos
		//A exibição do vetor na ordem inversa em que os elementos foram inseridos

		inteiro numeros[10] = {5, 8, 4, 1, 54, 6985, 142, 854, 25, 10}
		para(inteiro indice = 0; indice < 10; indice++) {
    		escreva( numeros[indice], ", ")}

    		para(inteiro indice = 9; indice >= 0; indice--) {
    		escreva(numeros[indice], ", ")}


	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 493; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */