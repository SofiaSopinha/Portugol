programa
{
	
	funcao inicio()
	{
		cadeia produto
		real valor
		inteiro desconto
		

		escreva("Insira o nome do produto: ")
		leia(produto)
		escreva("Insira o valor do produto:R$ ")
		leia(valor)
		escreva("Insira o valor do desconto: ")
		leia(desconto)

		se (desconto <0 ou desconto >100)
		escreva("Desconto inválido por favor, reinicie e coloque um valor válido")

		senao{
		real valor_desconto = valor * desconto / 100

		real valor_descontado = valor - valor_desconto

		escreva("=====INFORMAÇÕES DO PRODUTO=====\n")
		escreva("O nome do produto é: " + produto + "\n")
		escreva("O valor original do produto era: R$" + valor + "\n")
		escreva("O valor do produto, agora do desconto é de: R$" + valor_descontado )}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 724; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */