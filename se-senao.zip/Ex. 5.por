programa
{
	
	funcao inicio()
	{
		real largura
		real comprimento

		escreva("Por favor, insira a largura em metros: ")
		leia(largura)

		escreva("Agora, insira o comprimento em metros: ")
		leia(comprimento)

		real area = largura * comprimento

		se(largura > 0 e comprimento > 0)
		escreva("A área do comodo é igual a " + area + "m^2")

		senao{
			escreva("Impossível um cômodo com essa medida, amg ;-; ")
		}
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 364; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */