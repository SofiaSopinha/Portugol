programa
{
	
	funcao inicio()
	{
		inteiro idade

		escreva("Insira sua idade: \n")
		leia(idade)

			se(idade >= 110)
			escreva("Como você tem essa idade??? Fazer o quê, ")
			
			se(idade >= 18)
		
			escreva("Você é maior de idade, pode acessar.")
		
			senao{
		
			escreva("Você não é maior de idade, acesso negado.")}
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 196; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */