programa
{
	
	funcao inicio()
	{
		inteiro num
		escreva("Insira o número, por favor: ")
		leia(num)

		inteiro antecessor = (num - 1)
		inteiro sucessor = (num +  1)

		se(antecessor > 0 e sucessor > 0)
		escreva("O antecessor do seu número é: " + antecessor + "\n E o sucessor do seu número é: " + sucessor)

		
		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 310; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */