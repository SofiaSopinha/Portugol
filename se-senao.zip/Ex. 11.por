programa
{
	
	funcao inicio()
	{
		inteiro a
		inteiro b = 5

		escreva("Me fale um número e te direi se ele é divisível por 5: ")
		leia(a)
		
		

		inteiro resultado = (a % b)

		se(resultado == 0)
		escreva("Esse número é divisível por 5")

		senao
		escreva("Infelizmente, esse número não é divisível por 5")
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 144; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */