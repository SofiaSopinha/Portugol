
programa
{
	
	funcao inicio()
	{
	inteiro valor1
	inteiro valor2
		 escreva("Por favor, insira o primeiro valor: ")
		 leia(valor1)
		 escreva("Agora, insira o segundo valor: ")
		 leia(valor2)
	inteiro	 result = (valor1 + valor2)
	inteiro	 result1 = (valor1 - valor2)
	inteiro	 result2 = (valor1 * valor2)
	inteiro	 result3 = (valor1 / valor2)
		se(valor2 <= 0)
		escreva("==Algumas contas não poderão ser realizadas com esse valor, por favor, insira outro valor==")

		
	
	
		senao{
		 escreva("Os resultados das 4 operações desses dois valores são: " + "\n")
		 escreva("Soma: " + result + "\n")
		 escreva("Subtração: " + result1 + "\n")
		 escreva("Multiplicação: " + result2 + "\n")
		 escreva("Divisão: " + result3 + "\n")}

		 
		 
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 117; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */