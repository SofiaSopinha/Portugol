programa
{
	
	funcao inicio()
	{

		cadeia escolha_copoA
		escreva("O que vc quer colocar no Copo_A: ")
		leia(escolha_copoA)
		
		cadeia escolha_copoB
		escreva("O que vc quer colocar no Copo_B: ")
		leia(escolha_copoB)
		
		cadeia copo_A = escolha_copoA
		cadeia copo_B = escolha_copoB
		

		escreva("Copo_A está com " + escolha_copoA)
		escreva(" e Copo_B está com " + escolha_copoB)
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 391; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */