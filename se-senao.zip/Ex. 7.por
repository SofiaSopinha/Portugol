programa
{
	
	funcao inicio()
	{
		real valor
		escreva("Insira o valor que deseja: ")
		leia(valor)
		
		se(valor > 0){
		escreva("Esse número é positivo")
		}

		se(valor == 0)
		escreva("Esse número é igual a zero")

		se(valor < 0)
		escreva("Esse valor é negativo")
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 232; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */