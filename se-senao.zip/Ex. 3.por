programa
{
	
	funcao inicio()
	{
		real nota
		cadeia nome

		escreva("Insira o nome do aluno, assim poderemos personalizar a mensagem :D : ")
		leia(nome)
		escreva("Insira sua nota da prova: ")
		leia(nota)


		real faltou = (7 - nota)
				se(nota >10)
		 		escreva("Nota inválida")
		 		 senao
		 		
		 		se(nota >= 7 e nota <= 10){
		 		escreva("Você foi aprovado, parabéns!")
		 		}
		 		
		 	
		 		senao{
		 		escreva(nome + ", você está reprovado, que pena, faltou apenas: " + faltou + " pontos pra você passar ;[ ")
		 	}
		 
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 296; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */