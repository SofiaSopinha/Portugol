programa
{
	
	funcao inicio()
	{
		real nota1
		real nota2

		escreva("Insira sua primeira nota: ")
		leia(nota1)

		escreva("Agora, insira sua segunda nota: ")
		leia(nota2)
		
		real resultado = (nota1 + nota2) / 2
		real faltou = (6 - resultado)
		se(nota1 < 0 ou nota2 < 0 ou nota1 >10 )
		escreva("Insira uma nota válida")
		
		se(resultado >=6 e resultado <= 10)
		escreva("Você foi aprovado, parabéns!")
		
		se(resultado >= 0 e resultado <6)
		escreva("Você está reprovado, que pena,  faltou apenas: " + faltou + " pontos pra você passar ;[ ")
	
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 287; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */