programa
{
	
	funcao inicio()
	{

		real temperatura
		escreva("Insira a temperatura de hoje, por favor: ")
		leia(temperatura)

		 		se(temperatura >= 25){
		 		escreva("Está quente! Cuidado pra não derreter")
		 		}

	
		 		se(temperatura > 16 e temperatura < 25){
		 		escreva("Está um clima ameno! Aproveite o dia!")
		 		}

		 	
		 		se(temperatura <= 16)
		 	
		 		{
		 		escreva("Está frio! Cuidado para não virar um picolé!")
		 		}
		 		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 156; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */