programa
{
	
	funcao inicio()
	{
	
		cadeia palavra_secreta
		palavra_secreta = ("Adoleta")
		cadeia palavra_chute
		

		escreva("Escreva aqui seu chute para a palavra secreta: ")
		leia(palavra_chute)

		se(palavra_chute == palavra_secreta)
		escreva("Poxa, você acertou tão rápido... Parabéns!")

		senao
		escreva("Você errou a palavra! Tente de novo!")

		
	}
}
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 183; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */